#ifndef KONTAKT_H_INCLUDED
#define KONTAKT_H_INCLUDED

#include "string.h"
#include <iostream>
using namespace std;

class Kontakt{
    int id;
    String nev;
    String cim;
public:
    Kontakt(int id = 0, const char* n = "", const char* c = "") : id(id), nev(n), cim(c) {}
    virtual void kiir() const = 0;
    virtual void fajlbaIr(ostream &os) const = 0;

    virtual Kontakt* clone() const = 0;

    const String& getNev() const { return nev; }

    virtual ~Kontakt(){};

};

#endif // KONTAKT_H_INCLUDED

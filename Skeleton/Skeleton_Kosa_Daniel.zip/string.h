#ifndef STRING_H_INCLUDED
#define STRING_H_INCLUDED

#include <iostream>


class String {
    char *adat;    ///< pointer az adatra
    size_t hossz;     ///< hossz lez�r� nulla n�lk�l
public:

    String() : adat(nullptr), hossz(0) {}
    String(const char* txt) : adat(nullptr), hossz(0) {}
    String(const String& rhs) : adat(nullptr), hossz(0) {}
    ~String() {}

    String& operator=(const String& rhs) { return *this; }

    const char* c_str() const { return adat; }
};

#endif // STRING_H_INCLUDED
